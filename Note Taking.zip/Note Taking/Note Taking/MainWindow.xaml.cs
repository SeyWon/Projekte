﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Data;
using System.ComponentModel;
using System.Xml.Linq;
using System.Threading;

namespace Note_Taking
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            UpdateListBox();
            
        }

        
        // Beim Anklicken eins Items erscheint es direkt im Feld 
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        

            if (boxlist.SelectedItem != null) // funktioniert nur wenn etwas ausgehält ist 
            {
                string title = boxlist.SelectedItem.ToString();  //wir nehmen uns den Namen des Items  und speichern ihn
                titlebox.Text = title;  //Title Box bekommt Inhalt 

                StreamReader sr = new StreamReader(@"E:\Users\Fabi\Desktop\Coding\Note Taking\" + title); // wir suchen nun das Dokument mit dem namen des items der Listbox
                notebox.Text = sr.ReadToEnd(); //Inhalt wird gelesen und in der Note box ausgegeben 
                sr.Close(); // Dokument wird geschlossen
            }
            
        }
        
       
        private void OnKeyDown(object sender, KeyEventArgs e) // speichern mit Ctrl + S
        {


            if (Keyboard.IsKeyDown(Key.LeftCtrl))
            {
                titlebox.IsReadOnly = true;
                notebox.IsReadOnly = true;
                if (Keyboard.IsKeyDown(Key.LeftCtrl) && e.Key == Key.S && titlebox.Text != "" && notebox.Text != "") // Code wird nur ausgeführt wenn ctrl s gedrückt ist sowie beide Textboxen nicht leer sind 
                {

                    Saving();

                    //schöne grüße von der leo


                }
            }
            else
            {
                titlebox.IsReadOnly = false;
                notebox.IsReadOnly = false;
            }
            
        }
   
        private void DelKeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Delete && boxlist.SelectedItem != null)  // was passiert beim klicken des Delete key
            {

                string name = boxlist.SelectedItem.ToString();  // Soeichern des Datei namens
                MessageBoxResult result = MessageBox.Show("Sind sie sicher das sie " + name + " löschen wollen?","Achtung!", MessageBoxButton.YesNo); // Message box fragt ob wir sicher sind
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        boxlist.Items.Remove(boxlist.Items[boxlist.SelectedIndex]);
                        File.Delete(@"E:\Users\Fabi\Desktop\Coding\Note Taking\" + name);     // Textdokument wird im vorgegebenen Pfad mit vorher gespeichertem namen Gelöscht
                        titlebox.Clear();
                        notebox.Clear();

                        boxlist.SelectedItem = 0; //wichtig damit nich "null" ausgewählt ist 
                        break;

                    case MessageBoxResult.No:
                        break;
                }
            }
        } // löschen mit del key

        private void NewButt_Click(object sender, RoutedEventArgs e)
        {
            
            titlebox.Clear();
            notebox.Clear();
            boxlist.SelectedItem = null;
           
        } // "neue datei" erstellen (textfeld leeren und auswahl aufheben)

        private void SaveButt_Click(object sender, RoutedEventArgs e)
        {

            if (titlebox.Text != "" && notebox.Text != "") // Code wird nur ausgeführt wenn save gedrückt ist sowie beide Textboxen nicht leer sind 
            {
                Saving();
            }
        } // speichen mit button

        private void DeleteButt_Click(object sender, RoutedEventArgs e)
        {
            if (boxlist.SelectedItem != null)  // was passiert beim klicken des Delete key
            {

                string name = boxlist.SelectedItem.ToString();  // Soeichern des Datei namens
                MessageBoxResult result = MessageBox.Show("Sind sie sicher das sie " + name + " löschen wollen?", "Achtung!", MessageBoxButton.YesNo); // Message box fragt ob wir sicher sind
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        boxlist.Items.Remove(boxlist.Items[boxlist.SelectedIndex]);
                        File.Delete(@"E:\Users\Fabi\Desktop\Coding\Note Taking\" + name);     // Textdokument wird im vorgegebenen Pfad mit vorher gespeichertem namen Gelöscht
                        titlebox.Clear();
                        notebox.Clear();

                        boxlist.SelectedItem = 0; //wichtig damit nicht "null" ausgewählt ist 
                        break;

                    case MessageBoxResult.No:
                        break;
                }
            }
        } // löschen mit button

        private void Saving()
        {

            string schreiben = @"E:\Users\Fabi\Desktop\Coding\Note Taking\";
            string title = titlebox.Text;                   // Hier geben wir die paramenter wie speicherort und Dokument name 

            if (boxlist.SelectedItem != null)
            {
                File.Delete(schreiben + boxlist.SelectedItem.ToString());       // Haben wir eine Datei ausgwhält löschen wir sie um sie mit der neuen zu ersetzen
                UpdateListBox();                                                // damit faken wir eine Bearbeitungs funktion

            }

            if (titlebox.Text.Contains(".txt"))
            {

                File.WriteAllText(schreiben + title, notebox.Text); // Hier wird die Datei erstellt
                boxlist.Items.Clear();
               
                UpdateListBox();
                MessageBox.Show("Speichern erfolgreich");
                titlebox.Clear();
                notebox.Clear();

            }           // hier muss geschaut werdefn ob .txt schon vorhanden ist um doppeltes schreiben von .txt zu vermeiden

            else
            {
                File.WriteAllText(schreiben + title+".txt", notebox.Text); // Hier wird die Datei erstellt
                boxlist.Items.Clear();
                
                UpdateListBox();
                MessageBox.Show("Speichern erfolgreich");
                titlebox.Clear();
                notebox.Clear();
            }
        }
       
        private void UpdateListBox()
        {

            DirectoryInfo dinfo = new DirectoryInfo(@"E:\Users\Fabi\Desktop\Coding\Note Taking\");
            FileInfo[] Files = dinfo.GetFiles("*.txt"); // dieser Pfad wird nach Textdokumenten gesacannt 

            foreach (FileInfo file in Files)
            {
                boxlist.Items.Add(file.Name); // jedes Dokument wird als Item der Liste Hinzugefügt
            }


        } // liste neu laden.
    }
}
